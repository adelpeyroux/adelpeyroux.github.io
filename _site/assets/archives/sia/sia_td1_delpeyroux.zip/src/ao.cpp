#include "integrator.h"
#include "scene.h"
#include "material.h"
#include "warp.h"

class AO : public Integrator
{
public:
    AO(const PropertyList &props) {
        m_sampleCount = props.getInteger("samples", 10);
        m_cosineWeighted = props.getBoolean("cosine", true);
    }

    Color3f Li(const Scene *scene, const Ray &ray) const {
        Color3f radiance = Color3f::Zero();


        /* Find the surface that is visible in the requested direction */
        Hit hit;
        scene->intersect(ray, hit);
        if (hit.foundIntersection())
        {
            Normal3f normal = hit.normal();
            Point3f pos = ray.at(hit.t());

            const Material* material = hit.shape()->material();

            Vector3f u = normal.unitOrthogonal();
            Vector3f v = normal.cross(u);

            float visibility = 0;
            for (int i = 0; i < m_sampleCount; ++i) {
                Point2f sample = Point2f(Eigen::internal::random<float>(0,1),Eigen::internal::random<float>(0,1));

                Vector3f d = (m_cosineWeighted ? Warp::squareToCosineHemisphere(sample) : Warp::squareToUniformHemisphere(sample));

                Vector3f p = d.x() * u + d.y() * v + d.z() * normal;

                Ray occlusion_ray = Ray(pos + (0.0001 * normal), p , false);
                Hit occlusion_hit;

                scene->intersect(occlusion_ray, occlusion_hit);
                if (!occlusion_hit.foundIntersection()) { // Not shadowed
                    float cosTheta = normal.dot(p);
                    float pdf = (m_cosineWeighted ? Warp::squareToCosineHemispherePdf(d) : Warp::squareToUniformHemispherePdf(d));
                    visibility += (fabs(cosTheta) / M_PI) / fabs(pdf);
                }
            }

            radiance = Color3f(visibility / double(m_sampleCount));
        }

        return radiance;
    }

    std::string toString() const {
      return tfm::format("AO[\n"
                         "  samples = %f\n"
                         "  cosine-weighted = %s]\n",
                         m_sampleCount, 
                         m_cosineWeighted ? "true" : "false");
  }

private:
    int m_sampleCount;
    bool m_cosineWeighted;
};

REGISTER_CLASS(AO, "ao")
