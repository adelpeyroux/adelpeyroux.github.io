/*
    This file is part of Nori, a simple educational ray tracer

    Copyright (c) 2015 by Wenzel Jakob

    Nori is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License Version 3
    as published by the Free Software Foundation.

    Nori is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#include <warp.h>
#include <vector.h>

Point2f Warp::squareToUniformSquare(const Point2f &sample) {
    return sample;
}

float Warp::squareToUniformSquarePdf(const Point2f &sample) {
    return ((sample.array() >= 0).all() && (sample.array() <= 1).all()) ? 1.0f : 0.0f;
}

Point2f Warp::squareToUniformDisk(const Point2f &sample) {
    float theta = 2. * M_PI * sample.y();

    float r = sqrt(sample.x());

    return Point2f(r * cos(theta), r * sin(theta));
}

float Warp::squareToUniformDiskPdf(const Point2f &p) {
    return (p.norm() <= 1 ? 1. / M_PI : 0.0f);
}

Vector3f vector3fFromPhiTheta (float phi, float theta) {
    Vector3f u_value = sin(theta) * cos(phi) * Vector3f(1,0,0);
    Vector3f v_value = sin(theta) * sin(phi) * Vector3f(0,1,0);
    Vector3f w_value = cos(theta) * Vector3f(0,0,1);

    return u_value + v_value + w_value;
}

Vector3f Warp::squareToUniformHemisphere(const Point2f &sample) {

    float phi = 2 * M_PI * sample.x();
    float theta = acos(sample.y());

    return vector3fFromPhiTheta(phi, theta);
}

float Warp::squareToUniformHemispherePdf(const Vector3f &v) {
    return (v.norm() <=  1.001 && v.norm() >=  0.999 && v.z() >= 0 ? 1. / (2 * M_PI) : 0.0f);
}

Vector3f Warp::squareToCosineHemisphere(const Point2f &sample) {
    float phi = 2 * M_PI * sample.x();
    float theta = acos(sqrt(1 - sample.y()));

    return vector3fFromPhiTheta(phi, theta);
}

float Warp::squareToCosineHemispherePdf(const Vector3f &v) {
    float cosTheta = Vector3f(0,0,1).dot(v);
    return (v.norm() <=  1.001 && v.norm() >=  0.999 && v.z() >= 0 ? cosTheta / (M_PI) : 0.0f);
}
