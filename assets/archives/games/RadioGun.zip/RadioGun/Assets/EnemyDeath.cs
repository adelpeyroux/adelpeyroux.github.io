﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyDeath : MonoBehaviour {

	private Animator m_animator;

	public Transform m_loot;
	public float m_lootRate;

	// Use this for initialization
	void Start () {
		m_animator = gameObject.GetComponent<Animator> ();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnDestroy () {
		if (m_loot) {
			float dice = Random.Range (0, 1000) / 1000f;

			if (dice < m_lootRate) {
				Transform loot = Instantiate (m_loot) as Transform;
				loot.position = gameObject.transform.position;
			}
		}
	}

	public void Die () {
		Destroy (gameObject, 0.417f);
		if (m_animator) {
			m_animator.Play ("Death");
		}


	}

	void OnCollisionEnter2D (Collision2D coll) {
		if (coll.gameObject.CompareTag ("Bullet")) {
			Die ();
		}
	}
}
