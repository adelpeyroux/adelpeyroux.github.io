﻿using System;
using UnityEngine;

[Serializable]
public class OscParams
{

	private float carryingFreq;
	private float gain;

	private float m_sampleRate = (float)AudioSettings.outputSampleRate;

	private float cPhi;
	public float CarryingPhi {
		get { return cPhi; }
		set {
			cPhi = value;

			if (cPhi >= 2 * Mathf.PI)
				cPhi -= 2 * Mathf.PI;
		}
	}
	public float CarPhiIncr {
		get { return 2 * Mathf.PI * carryingFreq / m_sampleRate; }
	}

	private float modulatingFreq;
	private float I;

	private float mPhi;
	public float ModulatingPhi {
		get { return mPhi; }
		set {
			mPhi = value;

			if (mPhi >= 2 * Mathf.PI)
				mPhi -= 2 * Mathf.PI;
		}
	}
	public float ModPhiIncr {
		get { return 2 * Mathf.PI * modulatingFreq / m_sampleRate; }
	}

	public float duration;

	private ADSR adsr;

	public float computeADSR (float remains) {
		if (remains <= 0.0f)
			remains = 0.0f;
		if (remains >= duration)
			remains = duration;
		
		float t = (duration - remains) / duration;

		return adsr.Compute (t);
	}

	public OscParams (float fc, float g, float duration, 
		float fm = 0.0f, float i = 0.0f, 
		ADSR adsr = new ADSR())
	{
		carryingFreq = fc;
		gain = g;
		cPhi = 0.0f;

		this.duration = duration;

		modulatingFreq = fm;
		I = i;
		mPhi = 0.0f;

		this.adsr = adsr;
	}

	private void IncrCPhi () {
		CarryingPhi = CarryingPhi + CarPhiIncr;
	}
	private void IncrMPhi () {
		ModulatingPhi = ModulatingPhi + ModPhiIncr;
	}

	public void IncrPhis() {
		IncrCPhi ();
		IncrMPhi ();
	}

	public float GetSineWave() {
		return gain * Mathf.Sin(CarryingPhi + I * Mathf.Sin(ModulatingPhi));
	}
}