﻿using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using UnityEngine;

public class OscilatorFM : MonoBehaviour {
	public static OscilatorFM instance = null;

	public float m_gain = 1f;
	private int m_sampleFreq;

	private readonly object syncLock = new object ();

	private List<OscAndDuration> m_oscs;

	void OnAudioFilterRead(float[] data, int channels) {
		if (m_gain < 0f) {
			m_gain = 0f;
		}
		if (m_gain >= 1f) {
			m_gain = 1f;
		}


		float time_step = 1.0f / (float)m_sampleFreq;

		List<OscAndDuration> to_play = new List<OscAndDuration>(m_oscs);

		for (int i = 0; i < data.Length; i += channels) {
			int n = 0;

			foreach (OscAndDuration osc in to_play) {
				data [i] += osc.Osc.computeADSR (osc.Remains) * osc.Osc.GetSineWave ();
				osc.Osc.IncrPhis ();
				osc.DecrRemains (time_step);
			}

			if (n > 0)
				data [i] *= m_gain / n;

			for (int c = 1; c < channels; ++c) {
				data [i + c] = data [i];
			}
		}



	}

	void Awake () {
		if (instance == null) {
			instance = this;
			m_sampleFreq = AudioSettings.outputSampleRate;
			m_oscs = new List<OscAndDuration> ();
			DontDestroyOnLoad (gameObject);
		} else {
			Destroy (gameObject);
		}

	}

	void Update () {
		List<OscAndDuration> toRemove = new List<OscAndDuration> ();

		foreach (OscAndDuration osc in m_oscs) {
			if (osc.Remains < 0.0f) {
				toRemove.Add (osc);
			}
		}

		foreach (OscAndDuration osc in toRemove) {
			m_oscs.Remove (osc);
		}

	}

	private void AddOsc( OscParams osc ) {
		m_oscs.Add (new OscAndDuration (osc));
	}

	public void PlaySinus(float gain, float freq, float duration) {
		OscParams osc = new OscParams (freq, gain, duration);
		AddOsc (osc);
	}

	public void PlaySinusADSR(float gain, float freq, float duration, ADSR adsr) {
		OscParams osc = new OscParams (freq, gain, duration, 0.0f, 0.0f, adsr);
		AddOsc (osc);
	}

	public void PlayFM(float gain, float freq, float fm, float I, float duration) {
		OscParams osc = new OscParams (freq, gain, duration, fm, I);
		AddOsc (osc);
	}

	public void PlayFMADSR(float gain, float freq, float fm, float I, float duration, ADSR adsr) {
		OscParams osc = new OscParams (freq, gain, duration, fm, I, adsr);
		AddOsc (osc);
	}
}
