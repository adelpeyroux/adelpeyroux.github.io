﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioManager : MonoBehaviour {

	public static AudioManager instance = null;

	public AudioSource m_soundStream;
	public AudioSource m_musicStream;

	void Awake () {
		if (instance == null) {
			instance = this;
			DontDestroyOnLoad (gameObject);
		} else {
			Destroy (gameObject);
		}
	}

	// Update is called once per frame
	void Update () {
		
	}

	public void PlaySound (AudioClip sound, bool reverse = false) {
		m_soundStream.clip = sound;
		if (reverse) {
			m_soundStream.time = sound.length - 0.000001f;
			SoundPitch = -1.0f;
		} else {
			SoundPitch = 1.0f;
		}
		m_soundStream.Play ();
	}

	public void PlayMusic (AudioClip music, bool loop, bool reverse = false) {
		m_musicStream.clip = music;
		m_musicStream.loop = loop;

		if (reverse) {
			m_musicStream.time = music.length - 0.000001f;
			MusicPitch = -1.0f;
		} else {
			MusicPitch = 1.0f;
		}

		m_musicStream.Play();
	}

	public float SoundVolume {
		get { return m_soundStream.volume; }
		set { m_soundStream.volume = value;	}
	}

	public float MusicVolume {
		get { return m_musicStream.volume; }
		set { m_musicStream.volume = value; }
	}

	public float SoundPitch {
		get { return m_soundStream.pitch; }
		set { m_soundStream.pitch = value; }
	}

	public float MusicPitch {
		get { return m_musicStream.pitch; }
		set { m_musicStream.pitch = value; }
	}
}
