﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TempoEstimation : MonoBehaviour {

	public static TempoEstimation Instance = null;

	public AudioSource m_audio;
	private int m_sampleRate;

	[HideInInspector]
	public float m_estimatedTempo;

	public float m_threshold;

	public int m_hopSize;
	public int m_buffersize;

	[Header ("Events")]
	public OnBeatEventHandler onBeat;

	[System.Serializable]
	public class OnBeatEventHandler : UnityEngine.Events.UnityEvent
	{

	}

	private void autoCorelation (float [] buffer, int size, float[] result) {

		for (int tho = 0; tho < size; ++tho){
			result[tho] = 0.0f;
			for (int n = 0; n < size - tho; ++n) {
				result[tho] += buffer[n] * buffer[n + tho];
			}
			result[tho] *= 1.0f / (float)size;
		}

	}

	private float estimateTempo(float[] energies, int size) {
		float[] autoCorel = new float[size];
		autoCorelation (energies, size, autoCorel);

		float block_dur = ((float)m_hopSize / (float)m_sampleRate);

		int start = (int)(60f / (300f * block_dur));
		int end = (int)(60f / (30f * block_dur));

		List<int> indices = new List<int> ();

		float max = 0f;
		int maxi = 0;
		for (int i = start; i < end; ++i) {
			if (autoCorel [i] > autoCorel [i + 1] &&
				autoCorel [i] > autoCorel [i - 1] && 
				autoCorel [i] > max) {
				indices.Add (i);
				max = autoCorel [i];
				maxi = i;
			}
		}

		if (indices.Count > 1) {
			return 60f / (indices[1] * block_dur);
		} else if (indices.Count > 0) {
			return 60f / (indices[0] * block_dur);
		} else {
			return -1f;
		}
	}

	private void extract(float[] fromBuf, float[] toBuf, int offset, int size) {
		int index = 0;
		for (int i = offset; i < offset + size; ++i, ++index) {
			toBuf [index] = fromBuf [i];
		}
	}

	// Use this for initialization
	void Start () {
		if (Instance == null) {
			Instance = this;
			m_sampleRate = m_audio.clip.frequency;
			float[] samples = new float[m_audio.clip.samples * m_audio.clip.channels];
			m_audio.clip.GetData (samples, 0);

			float[] buffer = new float[m_buffersize * m_audio.clip.channels];

			float[] energies = new float[m_audio.clip.samples / m_hopSize];

			for (int i = 0; i < m_audio.clip.samples / m_hopSize; ++i) { // For each frame
				if (i < m_audio.clip.samples / m_hopSize - m_buffersize) {
					extract (samples, buffer, i * m_hopSize * m_audio.clip.channels, m_buffersize * m_audio.clip.channels);

					float energy = 0.0f;
					for (int j = 0; j < m_buffersize * m_audio.clip.channels; j += m_audio.clip.channels) { // For each sample in the frame
						float value = 0f;
						for (int c = 0; c < m_audio.clip.channels; ++c) {
							value += buffer [j + c];	
						}
						value /= m_audio.clip.channels;

						energy += value * value;
					}
					energy /= m_buffersize;

					if (energy > m_threshold)
						energies [i] = energy;
				}
			}

			m_estimatedTempo = estimateTempo (energies, m_audio.clip.samples / m_hopSize);

			float period = 1f / (m_estimatedTempo / 60f);

			InvokeRepeating ("InvokeOnBeat", 0f, period);
		} else {
			Destroy (gameObject);
		}

	}

	private void InvokeOnBeat () {
		onBeat.Invoke ();
	}

	// Update is called once per frame
	void Update () {
		
	}
}
