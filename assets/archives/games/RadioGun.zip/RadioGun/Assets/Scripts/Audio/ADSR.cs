﻿using System;
using UnityEngine;

public struct ADSR
{
	public ADSR(float a, float d, float s, float r) {
		Attack = a;
		Decay = d;
		Sustain = s; 
		Release = r;
	}

	public float Attack;
	public float Decay;
	public float Sustain;
	public float Release;

	public float Compute (float time) {
		float value = 1.0f;

		if (time < Attack)
			value = time / Attack;
		else if (time < Attack + Decay)
			value = -(Sustain / Decay) * time + (1.0f + (Sustain / Decay) * Attack);
		else if (time < 1.0F - Release)
			value = Sustain;
		else
			value = Mathf.Max (0.0f, -(Sustain / Release) * time + (Sustain / Release));

		Console.Write (value.ToString());
		return value;
	}
}

