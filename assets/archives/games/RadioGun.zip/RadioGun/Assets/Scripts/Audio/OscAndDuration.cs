﻿using System;

public class OscAndDuration
{
	public OscParams Osc;
	public float Remains;

	public OscAndDuration(OscParams osc) {
		Osc = osc;
		Remains = osc.duration;
	}

	public void DecrRemains (float time_step) {
		Remains -= time_step;
	}
}


