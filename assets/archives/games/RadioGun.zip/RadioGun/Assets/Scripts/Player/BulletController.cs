﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletController : MonoBehaviour {

	private Animator m_anim;
	private SpriteRenderer m_render;

	[HideInInspector]
	public int m_direction = 1;

	public float m_speed;

	// Use this for initialization
	void Awake () {
		m_anim = gameObject.GetComponent<Animator> ();
		m_render = gameObject.GetComponent<SpriteRenderer> ();
	}
	
	// Update is called once per frame
	void Update () {
		transform.Translate (new Vector3 (m_direction * m_speed * Time.deltaTime, 0, 0));
	}

	void OnCollisionEnter2D (Collision2D coll) {
		if (coll.gameObject.CompareTag ("Powerup") || coll.gameObject.CompareTag ("Player")) {
			Physics2D.IgnoreCollision (coll.gameObject.GetComponent<BoxCollider2D> (), gameObject.GetComponent<BoxCollider2D> ());
		} else {
			m_speed = 0;
			transform.position = new Vector3 (coll.contacts[0].point.x, coll.contacts[0].point.y, transform.position.z);
			m_anim.Play ("Impact");
			Destroy (gameObject, 0.35f);

		} 
	}
}
