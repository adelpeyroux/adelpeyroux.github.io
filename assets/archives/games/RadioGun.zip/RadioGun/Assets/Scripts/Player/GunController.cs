﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GunController : MonoBehaviour {

	private PlayerController m_player;

	public Transform m_bulletR;
	public Transform m_bulletD;
	public Transform m_bulletS;

	private void OnBeat () {
		if (m_player.is_firing) {
			ADSR adsr = new ADSR (0.05f, 0.3f, 0.4f, 0.3f);
			OscilatorFM.instance.PlaySinusADSR (0.9f, 40f, 0.3f, adsr);
			OscilatorFM.instance.PlaySinusADSR (0.6f, 300f, 0.3f, adsr);

			Transform bullet;

			if (m_player.is_ducking) {
				bullet = Instantiate (m_bulletD) as Transform;
			} else if (m_player.is_moving) {
				bullet = Instantiate (m_bulletR) as Transform;
			} else {
				bullet = Instantiate (m_bulletS) as Transform;
			}
			Vector3 bulletPos = new Vector3 ((m_player.is_right ? 1f : -1f) * bullet.position.x, 
				                    bullet.position.y,
				                    bullet.position.z);
			
			Vector3 totalPos = bulletPos + gameObject.transform.position;

			bullet.position = new Vector3 (totalPos.x, totalPos.y, bullet.position.z);
			bullet.Rotate (0f, m_player.is_right ? 0f : 180f, 0f);
		}
	}

	// Use this for initialization
	void Start () {
		TempoEstimation estimator = FindObjectOfType<TempoEstimation>();
		estimator.onBeat.AddListener (OnBeat);

		m_player = gameObject.GetComponent<PlayerController> ();
	}
	
	// Update is called once per frame
	void Update () {
	}
}
