﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {

	public float m_speed = 100;

	public int m_life;

	[HideInInspector]
	public bool is_moving;

	[HideInInspector]
	public bool is_jumping;

	[HideInInspector]
	public bool is_ducking;

	[HideInInspector]
	public bool is_firing;

	[HideInInspector]
	public bool is_right;

	[HideInInspector]
	public bool is_hurt;
	private float remains = 0f;

	private Animator m_animator;
	private SpriteRenderer m_renderer;
	private Rigidbody2D m_rigidbody;
		
	// Use this for initialization
	void Awake () {
		is_right = true;
		is_moving = false;
		is_jumping = false;
		is_ducking = false;
		is_hurt = false;

		m_animator = gameObject.GetComponent<Animator> ();
		m_renderer = gameObject.GetComponent<SpriteRenderer> ();
		m_rigidbody = gameObject.GetComponent<Rigidbody2D> ();
	}

	// Update is called once per frame
	void Update () {
		is_moving = false;
		is_ducking = false;
		is_firing = false;

		if (!(is_hurt && remains > 0f) && m_life > 0) {
			if (Input.GetKey (KeyCode.X) && !is_jumping) {
				is_firing = true;
			}

			if (Input.GetKey (KeyCode.DownArrow) && !is_jumping && !is_moving) {
				is_ducking = true;
			}

			if (Input.GetKey (KeyCode.RightArrow) && !is_ducking) {
				gameObject.transform.Translate (new Vector3 (m_speed * Time.deltaTime, 0f, 0f));
				is_moving = true;
				is_right = true;
				if (m_renderer)
					m_renderer.flipX = false;
			}

			if (Input.GetKey (KeyCode.LeftArrow) && !is_ducking) {
				gameObject.transform.Translate (new Vector3 (-m_speed * Time.deltaTime, 0f, 0f));
				is_moving = true;
				is_right = false;
				if (m_renderer)
					m_renderer.flipX = true;	
			}

			if (Input.GetKeyDown (KeyCode.C) && !is_jumping && !is_ducking) {
				m_rigidbody.AddForce (new Vector2 ((is_moving ? (is_right ? 0.05f : -0.05f) : 0f), 0.45f), ForceMode2D.Impulse);
				is_jumping = true;

			}
			if (m_animator) {
				if (is_jumping) {
					m_animator.Play ("PlayerJump");
				} else if (is_moving) {
					if (is_firing) {
						m_animator.Play ("PlayerRunShoot");
					} else {
						m_animator.Play ("PlayerRun");
					}
				} else if (is_ducking) {
					m_animator.Play ("PlayerDuck");
				} else {
					if (is_firing)
						m_animator.Play ("PlayerStand");
					else
						m_animator.Play ("PlayerIdle");
				}
			}
		} else {
			if (remains > Time.deltaTime) {
				if (m_animator) {
					m_animator.Play ("PlayerHurt");
					remains -= Time.deltaTime;
				} 
			} else {
				if (m_life <= 0) {
					if (m_animator) {
						m_animator.Play ("Death");
						Destroy (gameObject, 0.417f);
					}
				}
			}
		} 


	}

	void OnCollisionEnter2D (Collision2D coll) {
		if (coll.gameObject.CompareTag("Ground")) {
			is_jumping = false;
		}

		if (coll.gameObject.CompareTag("Powerup")) {
			ADSR adsr = new ADSR (0.05f, 0f, 1f, 0.95f);
			OscilatorFM.instance.PlaySinusADSR (0.5f, 870f, 0.4f, adsr);
			OscilatorFM.instance.PlaySinusADSR (0.5f, 890f, 0.4f, adsr);
			Destroy(coll.gameObject);
		}

		if (coll.gameObject.CompareTag("Enemy")) {
			m_life -= 1;
			is_hurt = true;
			remains = 0.167f * 2;
			m_rigidbody.AddForce (new Vector2 ((is_right ? -0.03f : 0.03f), 0.0f), ForceMode2D.Impulse);
			EnemyDeath ed = coll.gameObject.GetComponent<EnemyDeath> ();
			if (ed) {
				ed.Die ();
			}
		}
	}
}
