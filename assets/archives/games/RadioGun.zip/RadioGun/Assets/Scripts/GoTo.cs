﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoTo : MonoBehaviour {

	public float m_speed;

	public bool is_right;

	private SpriteRenderer m_renderer;

	// Use this for initialization
	void Start () {
		m_renderer = gameObject.GetComponent<SpriteRenderer> ();
	}
	
	// Update is called once per frame
	void Update () {
		PlayerController m_target = FindObjectOfType<PlayerController>();

		if (m_target) {
			Vector3 direction = m_target.gameObject.transform.position - transform.position;
			direction.Normalize ();

			is_right = Vector3.Dot (direction, new Vector3 (1, 0, 0)) > 0;

			gameObject.transform.Translate (m_speed * direction * Time.deltaTime);
		}

		if (m_renderer) {
			m_renderer.flipX = is_right;
		}
	}
}
