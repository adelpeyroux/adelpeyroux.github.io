﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Follow : MonoBehaviour {

	public GameObject _object;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if (_object) {
			Vector3 new_pos = _object.transform.position;
			new_pos.z = transform.position.z;
			transform.position = new_pos;
		}
	}
}
