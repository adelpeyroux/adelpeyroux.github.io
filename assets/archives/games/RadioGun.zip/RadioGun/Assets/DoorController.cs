﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DoorController : MonoBehaviour {

	void OnBeat () {
		m_current += 1;
		m_current %= m_nbPulse;


		if (m_current == 0 && m_spawn) {
			Transform mob = Instantiate (m_spawn) as Transform;
			mob.position = gameObject.transform.position;
		}
	}

	public int m_nbPulse;
	private int m_current = 1;

	public Transform m_spawn;

	// Use this for initialization
	void Start () {
		TempoEstimation estimator = FindObjectOfType<TempoEstimation>();
		estimator.onBeat.AddListener (OnBeat);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
