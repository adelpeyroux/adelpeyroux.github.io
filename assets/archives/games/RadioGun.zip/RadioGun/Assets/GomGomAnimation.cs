﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GomGomAnimation : MonoBehaviour {

	private void OnBeat () {
		m_state = (m_state + 1) % 4; 
	}

	public int m_state;

	public Sprite m_state0;
	public Sprite m_state1;

	private SpriteRenderer m_renderer;

	// Use this for initialization
	void Start () {
		TempoEstimation estimator = FindObjectOfType<TempoEstimation>();
		estimator.onBeat.AddListener (OnBeat);

		m_renderer = gameObject.GetComponent<SpriteRenderer> ();
	}
	
	// Update is called once per frame
	void Update () {

		if (m_renderer && m_state0 && m_state1) {
			if (m_state < 2) {
				m_renderer.sprite = m_state0;
			} else {
				m_renderer.sprite = m_state1;
			}
		}
	}
}
