#pragma once

#include <glbinding/nogl.h>

#include <glbinding/gl/extension.h>
#include <glbinding/gl12ext/types.h>
#include <glbinding/gl12ext/boolean.h>
#include <glbinding/gl12ext/values.h>
#include <glbinding/gl12ext/bitfield.h>
#include <glbinding/gl12ext/enum.h>
#include <glbinding/gl12ext/functions.h>
