#include "material.h"
#include "warp.h"

Ward::Ward(const PropertyList &propList)
    : Diffuse(propList.getColor("diffuse",Color3f(0.2)))
{
    m_reflectivity = propList.getColor("reflectivity",Color3f(0.0));
    m_transmissivness = propList.getColor("transmissivness",Color3f(0.0));
    m_etaA = propList.getFloat("etaA",1);
    m_etaB = propList.getFloat("etaB",1);
    m_specularColor = propList.getColor("specular",Color3f(0.9));
    m_alphaX = propList.getFloat("alphaX",0.2);
    m_alphaY = propList.getFloat("alphaY",0.2);

    std::string texturePath = propList.getString("texture","");
    if(texturePath.size()>0){
        filesystem::path filepath = getFileResolver()->resolve(texturePath);
        loadTextureFromFile(filepath.str());
        setTextureScale(propList.getFloat("scale",1));
        setTextureMode(TextureMode(propList.getInteger("mode",0)));
    }
}

Color3f Ward::brdf(const Vector3f& viewDir, const Vector3f& lightDir, const Normal3f& normal, const Vector2f& uv) const
{
    Color3f diffuse = diffuseColor(uv) / M_PI;

    Color3f rhoS = m_specularColor;
    float ax = m_alphaX;
    float ay = m_alphaY;

    Vector3f i = lightDir;
    Vector3f o = viewDir;

    Vector3f n = normal;
    Vector3f d(0,1,0);
    Vector3f x = (d - ((d.dot(n)) * n)).normalized();
    Vector3f y = x.cross(n);

    Vector3f h = (i + o).normalized();

    float hDotN = h.dot(n);
    float hDotX = h.dot(x);
    float hDotY = h.dot(y);

    Color3f fr;

    float squareTerm = (i.dot(n)) * (o.dot(n));
    if (squareTerm > 0) {

        float exponent = (((hDotX / ax) * (hDotX / ax)) + ((hDotY / ay) * (hDotY / ay))) / (hDotN * hDotN);

        fr = (rhoS / (4 * M_PI * ax * ay * sqrt(squareTerm))) * exp(-exponent);
    }

    Color3f brdf_value = diffuse + fr;

    return brdf_value;
}

Color3f Ward::premultBrdf(const Vector3f& viewDir, const Vector3f& lightDir, const Normal3f& normal, const Vector2f& uv) const {
    Color3f specular = m_specularColor;
    Vector3f h = (viewDir + lightDir).normalized();

    float hDotN = h.dot(normal);

    float hDotN3 = hDotN * hDotN * hDotN;

    float denom = viewDir.dot(normal);

    if (denom < Epsilon)
        return Color3f::Zero();

    float squareTerm = lightDir.dot(normal) / viewDir.dot(normal);

    if (squareTerm < Epsilon)
        return diffuseColor(uv);

    return diffuseColor(uv) + specular * h.dot(viewDir) * hDotN3 * sqrtf(squareTerm);
}

std::string Ward::toString() const {
    return tfm::format(
        "Ward [\n" 
        "  diffuse color = %s\n"
        "  specular color = %s\n"
        "  alphaX = %f  alphaY = %f\n"
        "]", m_diffuseColor.toString(),
             m_specularColor.toString(),
             m_alphaX, m_alphaY);
}

Vector3f Ward::IS(const Vector3f& normal, const Vector3f& x, const Vector3f& y, const Vector3f& i, float u, float v, float& pdf, Color3f& brdf, float& cos_term, Vector2f texcoord) const {
    float avgSpec = m_specularColor.mean();
    float avgDiff = m_diffuseColor.mean();

    float rand = Eigen::internal::random<float>(0,1);
    if (rand >= (avgSpec / (avgSpec + avgDiff))) {
        float aX = getAlphaX();
        float aY = getAlphaY();

        float phiH = atanf(aY * tanf( 2 * M_PI * v) / aX);

        float cosphi = cosf(phiH);
        float cosphi2 = cosphi * cosphi;
        float sinphi = sinf(phiH);
        float sinphi2 = sinphi * sinphi;

        float aX2 = aX * aX;
        float aY2 = aY * aY;

        float thetaH = atanf(sqrtf((-logf(u)) / ((cosphi2 / aX2) + (sinphi2 / aY2))));

        Vector3f h = Vector3f(cosf(phiH) * sinf(thetaH),
                              sinf(thetaH) * sinf(phiH),
                              cosf(thetaH));

        h = h.x() * x + h.y() * y + h.z() * normal;

        Vector3f r= (2*(i.dot(h))*h) - i;
        brdf = this->premultBrdf(i, r, normal, texcoord);

        return r;
    }

    return US(normal, x, y, i, u, v, pdf, brdf, cos_term, texcoord);
}

Vector3f Ward::US(const Vector3f& normal, const Vector3f& x, const Vector3f& y, const Vector3f& i, float u, float v, float& pdf, Color3f& brdf, float& cos_term, Vector2f texcoord) const {
    (void)i; //we ignore this parameter

    Vector3f d = Warp::squareToCosineHemisphere(Vector2f(u,v));
    pdf = Warp::squareToCosineHemispherePdf(d);

    Vector3f r = d.x() * x + d.y() * y + d.z() * normal;
    cos_term = std::max(0.f,r.dot(normal));
    brdf = this->brdf(i, r, normal, texcoord);

    return r;
}

REGISTER_CLASS(Ward, "ward")
