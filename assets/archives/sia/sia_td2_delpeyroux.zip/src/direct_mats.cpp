#include "integrator.h"
#include "scene.h"
#include "material.h"
#include "warp.h"

class DirectMats : public Integrator
{
public:
    DirectMats(const PropertyList &props) {
        m_sampleCount = props.getInteger("samples",4);
        m_IS = props.getBoolean("IS", false);
    }

    Color3f Li(const Scene *scene, const Ray &ray) const {
        Hit hit;
        scene->intersect(ray, hit);
        if (!hit.foundIntersection())
            return scene->backgroundColor(ray.direction);

        Color3f radiance = Color3f::Zero();
        const Material* material = hit.shape()->material();

        const Ward* ward = dynamic_cast<const Ward*>(material);

        if (!ward)
            return scene->backgroundColor(ray.direction);

        Normal3f normal = hit.normal();
        Point3f pos = ray.at(hit.t());

        for(int i=0; i<m_sampleCount; ++i){
            Vector3f x = normal.unitOrthogonal();
            Vector3f y = normal.cross(x);

            Vector3f d;

            float u = Eigen::internal::random<float>(0,1);
            float v = Eigen::internal::random<float>(0,1);

            Vector3f r;
            Color3f brdf;
            float cos_term = 1.f;
            float pdf = 1.f;

            if (m_IS) {
                r = ward->IS(normal, x, y, -ray.direction, u, v, pdf, brdf, cos_term, hit.texcoord());
            } else {
                r = ward->US(normal, x, y, -ray.direction, u, v, pdf, brdf, cos_term, hit.texcoord());
            }

            Ray shadow_ray(pos + normal*Epsilon, r, true);
            Hit shadow_hit;
            scene->intersect(shadow_ray,shadow_hit);

            if (pdf > Epsilon) {
                if(!shadow_hit.foundIntersection()){
                  radiance += brdf * cos_term * scene->backgroundColor(r) / pdf;
                }
            }
        }
        return radiance / m_sampleCount;
    }

    std::string toString() const {
        return tfm::format("DirectMats[\n"
                           "  samples = %f\n"
                           "  IS = %s\n"
                           " ]\n",
                           m_sampleCount,
                           m_IS ? "true" : "false");
    }

private:
    int m_sampleCount;
    bool m_IS;
};

REGISTER_CLASS(DirectMats, "direct_mats")
