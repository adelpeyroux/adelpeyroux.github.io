#ifndef DIRECTMATS_H
#define DIRECTMATS_H


class DirectMats : public Integrator
{
public:
    DirectMats();
};

#endif // DIRECTMATS_H